﻿using BuildIndia.Service.Repository;
using BuildIndia.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;

namespace DummyWebApi.Controller
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]

    public class CompactorController : ApiController
    {
        private CompactorRepository _compRepo;
        public CompactorController()
        {
            _compRepo = new CompactorRepository();
        }
        public IHttpActionResult Get()
        {
            return Ok(_compRepo.GetAllCompactors());
        }
        [HttpPost]
        public IHttpActionResult PostAddCompactor(CompactorViewModel compactor)
        {
            _compRepo.Save(compactor);
            return Ok();
        }
    }
}
